package br.com.riscos.domain;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "cliente", uniqueConstraints = @UniqueConstraint(name = "uk_cliente_documento", columnNames = "cpf_cnpj"))
public class Cliente {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
  @Enumerated(EnumType.STRING) @Column(name = "tipo_pessoa", nullable = false, length = 2) private TipoPessoa tipoPessoa;
  @Column(name = "nome_social", nullable = false, length = 160) private String nomeSocial;
  @Column(name = "cpf_cnpj", nullable = false, length = 18) private String cpfCnpj;
  @Column(name = "data_cadastro", nullable = false) private LocalDate dataCadastro;
  @Enumerated(EnumType.STRING) @Column(name = "origem_cadastro", nullable = false, length = 3) private OrigemCadastro origemCadastro;
  @Column(name = "status_cliente", nullable = false, length = 30) private String statusCliente = "ATIVO";
  public Long getId(){return id;} public void setId(Long v){id=v;}
  public TipoPessoa getTipoPessoa(){return tipoPessoa;} public void setTipoPessoa(TipoPessoa v){tipoPessoa=v;}
  public String getNomeSocial(){return nomeSocial;} public void setNomeSocial(String v){nomeSocial=v;}
  public String getCpfCnpj(){return cpfCnpj;} public void setCpfCnpj(String v){cpfCnpj=v;}
  public LocalDate getDataCadastro(){return dataCadastro;} public void setDataCadastro(LocalDate v){dataCadastro=v;}
  public OrigemCadastro getOrigemCadastro(){return origemCadastro;} public void setOrigemCadastro(OrigemCadastro v){origemCadastro=v;}
  public String getStatusCliente(){return statusCliente;} public void setStatusCliente(String v){statusCliente=v;}
  public enum TipoPessoa { PF, PJ }
  public enum OrigemCadastro { APP, WEB }
}
