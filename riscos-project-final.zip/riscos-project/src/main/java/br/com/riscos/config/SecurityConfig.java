package br.com.riscos.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.*;
import org.springframework.core.type.AnnotatedTypeMetadata;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtDecoders;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableMethodSecurity
public class SecurityConfig {
  @Bean
  SecurityFilterChain security(HttpSecurity http, @Value("${JWT_ISSUER_URI:}") String issuer) throws Exception {
    http.csrf(csrf -> csrf.disable()).cors(cors -> {}).sessionManagement(s -> s.sessionCreationPolicy(SessionCreationPolicy.STATELESS));
    if (issuer == null || issuer.isBlank()) {
      http.authorizeHttpRequests(a -> a.requestMatchers("/actuator/health", "/api/auth/config", "/api/ocorrencias/**").permitAll().anyRequest().permitAll());
    } else {
      http.authorizeHttpRequests(a -> a.requestMatchers("/actuator/health", "/api/auth/config").permitAll().anyRequest().authenticated())
        .oauth2ResourceServer(o -> o.jwt(j -> {}));
    }
    return http.build();
  }
  @Bean @Conditional(JwtIssuerCondition.class)
  JwtDecoder jwtDecoder(@Value("${JWT_ISSUER_URI}") String issuer) { return JwtDecoders.fromIssuerLocation(issuer); }
  static class JwtIssuerCondition implements Condition {
    public boolean matches(ConditionContext c, AnnotatedTypeMetadata m) { String v=c.getEnvironment().getProperty("JWT_ISSUER_URI"); return v != null && !v.isBlank(); }
  }
}
