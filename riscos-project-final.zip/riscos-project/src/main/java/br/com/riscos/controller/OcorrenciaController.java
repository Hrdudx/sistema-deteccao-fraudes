package br.com.riscos.controller;

import br.com.riscos.domain.Ocorrencia;
import br.com.riscos.service.OcorrenciaService;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/ocorrencias")
@CrossOrigin(origins="${FRONTEND_ORIGIN:http://localhost:5173}", allowCredentials="true")
public class OcorrenciaController {
  private final OcorrenciaService service;
  public OcorrenciaController(OcorrenciaService service){this.service=service;}
  @GetMapping public List<Ocorrencia> listar(@RequestParam(required=false) Ocorrencia.Tipo tipo, @RequestParam(required=false) Long clienteId){return service.listar(tipo,clienteId);}
  @PostMapping @PreAuthorize("hasAnyAuthority('SCOPE_risk:write','ROLE_ADMIN')") public Ocorrencia criar(@Valid @RequestBody Ocorrencia o){return service.criar(o);}
  @PutMapping("/{id}/status") @PreAuthorize("hasAnyAuthority('SCOPE_risk:write','ROLE_ADMIN')") public Ocorrencia atualizarStatus(@PathVariable Long id,@RequestParam Ocorrencia.Status status){return service.atualizarStatus(id,status);}
}
