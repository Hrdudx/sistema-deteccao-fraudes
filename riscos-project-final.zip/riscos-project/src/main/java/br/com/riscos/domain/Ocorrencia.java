package br.com.riscos.domain;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "ocorrencia")
public class Ocorrencia {
  @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
  @Column(name = "cliente_id", nullable = false) private Long clienteId;
  @Column(name = "transacao_id") private Long transacaoId;
  @Enumerated(EnumType.STRING) @Column(nullable = false, length = 20) private Tipo tipo;
  @Column(nullable = false, length = 120) private String descricao;
  @Enumerated(EnumType.STRING) @Column(nullable = false, length = 20) private Status status = Status.ABERTA;
  @Column(name = "criada_em", nullable = false) private Instant criadaEm = Instant.now();
  @Column(name = "atualizada_em", nullable = false) private Instant atualizadaEm = Instant.now();
  @PreUpdate void touch(){atualizadaEm=Instant.now();}
  public Long getId(){return id;} public Long getClienteId(){return clienteId;} public void setClienteId(Long v){clienteId=v;}
  public Long getTransacaoId(){return transacaoId;} public void setTransacaoId(Long v){transacaoId=v;}
  public Tipo getTipo(){return tipo;} public void setTipo(Tipo v){tipo=v;}
  public String getDescricao(){return descricao;} public void setDescricao(String v){descricao=v;}
  public Status getStatus(){return status;} public void setStatus(Status v){status=v;}
  public Instant getCriadaEm(){return criadaEm;} public Instant getAtualizadaEm(){return atualizadaEm;}
  public enum Tipo { KYC, PLD, FRAUDE, CHARGEBACK }
  public enum Status { ABERTA, EM_ANALISE, RESOLVIDA, CANCELADA }
}
