package br.com.riscos.databricks;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;
@Configuration
@EnableConfigurationProperties(DatabricksClient.Properties.class)
public class DatabricksConfig {}
