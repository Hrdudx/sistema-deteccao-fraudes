package br.com.riscos.controller;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
@RestController
@RequestMapping("/api/auth")
public class AuthController {
  @GetMapping("/config") public Map<String,Object> config(@Value("${JWT_ISSUER_URI:}") String issuer){return Map.of("authenticationEnabled", !issuer.isBlank(), "requiredScopes", new String[]{"risk:read","risk:write"});}
}
