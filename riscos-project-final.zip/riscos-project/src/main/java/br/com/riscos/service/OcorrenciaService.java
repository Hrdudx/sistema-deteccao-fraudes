package br.com.riscos.service;

import br.com.riscos.domain.Ocorrencia;
import br.com.riscos.repository.OcorrenciaRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;
import java.util.List;

@Service
public class OcorrenciaService {
  private final OcorrenciaRepository repository;
  public OcorrenciaService(OcorrenciaRepository repository){this.repository=repository;}
  public Ocorrencia criar(Ocorrencia o){
    if (o.getClienteId()==null || o.getTipo()==null || o.getDescricao()==null || o.getDescricao().isBlank()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "clienteId, tipo e descricao são obrigatórios");
    if (o.getStatus()==null) o.setStatus(Ocorrencia.Status.ABERTA);
    return repository.save(o);
  }
  public List<Ocorrencia> listar(Ocorrencia.Tipo tipo, Long clienteId){
    if (tipo != null) return repository.findByTipo(tipo);
    if (clienteId != null) return repository.findByClienteId(clienteId);
    return repository.findAll();
  }
  public Ocorrencia atualizarStatus(Long id, Ocorrencia.Status status){
    Ocorrencia o=repository.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,"Ocorrência não encontrada"));
    o.setStatus(status); return repository.save(o);
  }
}
