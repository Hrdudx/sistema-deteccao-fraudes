package br.com.riscos.controller;
import br.com.riscos.databricks.DatabricksClient;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
@RestController
@RequestMapping("/api/databricks")
public class DatabricksController {
  private final DatabricksClient client;
  public DatabricksController(DatabricksClient client){this.client=client;}
  @GetMapping("/status") public Map<String,Object> status(){return Map.of("enabled",client.enabled());}
  @PostMapping("/query") @PreAuthorize("hasAnyAuthority('SCOPE_risk:read','ROLE_ADMIN')") public Map<String,Object> query(@RequestBody Map<String,String> body){
    String sql=body.getOrDefault("sql","").trim();
    if(sql.isBlank() || !sql.toLowerCase().startsWith("select")) throw new IllegalArgumentException("Somente consultas SELECT são permitidas");
    return client.execute(sql);
  }
}
