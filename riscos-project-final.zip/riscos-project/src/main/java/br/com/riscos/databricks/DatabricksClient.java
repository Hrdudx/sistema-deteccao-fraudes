package br.com.riscos.databricks;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import java.time.Duration;
import java.util.*;

@Component
public class DatabricksClient {
  private final Properties p; private final RestTemplate http;
  public DatabricksClient(Properties p, RestTemplateBuilder builder){this.p=p; this.http=builder.setConnectTimeout(Duration.ofSeconds(10)).setReadTimeout(Duration.ofSeconds(p.timeoutSeconds())).build();}
  public boolean enabled(){return p.enabled() && !p.host().isBlank() && !p.token().isBlank() && !p.warehouseId().isBlank();}
  public Map<String,Object> execute(String sql){
    if(!enabled()) throw new IllegalStateException("Integração Databricks não configurada");
    String host=p.host().replaceAll("/$","");
    Map<String,Object> body=Map.of("warehouse_id",p.warehouseId(),"catalog",p.catalog(),"schema",p.schema(),"statement",sql,"wait_timeout","10s","disposition","INLINE");
    HttpHeaders h=new HttpHeaders(); h.setBearerAuth(p.token()); h.setContentType(MediaType.APPLICATION_JSON);
    ResponseEntity<Map> r=http.exchange(host+"/api/2.0/sql/statements",HttpMethod.POST,new HttpEntity<>(body,h),Map.class);
    return r.getBody()==null?Map.of():r.getBody();
  }
  @ConfigurationProperties(prefix="databricks") public record Properties(boolean enabled,String host,String token,String warehouseId,String catalog,String schema,int timeoutSeconds) {}
}
