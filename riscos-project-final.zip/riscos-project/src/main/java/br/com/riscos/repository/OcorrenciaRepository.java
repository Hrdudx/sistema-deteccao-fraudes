package br.com.riscos.repository;
import br.com.riscos.domain.Ocorrencia;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
public interface OcorrenciaRepository extends JpaRepository<Ocorrencia, Long> {
  List<Ocorrencia> findByTipo(Ocorrencia.Tipo tipo);
  List<Ocorrencia> findByClienteId(Long clienteId);
}
