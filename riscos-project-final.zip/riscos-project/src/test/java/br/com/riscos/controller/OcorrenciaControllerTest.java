package br.com.riscos.controller;

import br.com.riscos.domain.Ocorrencia;
import br.com.riscos.service.OcorrenciaService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import java.util.List;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(OcorrenciaController.class)
class OcorrenciaControllerTest {
  @Autowired MockMvc mvc;
  @MockBean OcorrenciaService service;
  @Test @WithMockUser(authorities="SCOPE_risk:read") void listaOcorrencias(){when(service.listar(null,null)).thenReturn(List.of()); try{mvc.perform(get("/api/ocorrencias")).andExpect(status().isOk()).andExpect(content().json("[]"));}catch(Exception e){throw new RuntimeException(e);}}
  @Test void bloqueiaCriacaoSemPermissao() throws Exception {mvc.perform(post("/api/ocorrencias").contentType(MediaType.APPLICATION_JSON).content("{\"clienteId\":1,\"tipo\":\"PLD\",\"descricao\":\"alerta\"}" )).andExpect(status().isForbidden());}
}
