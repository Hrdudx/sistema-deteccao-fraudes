package br.com.riscos.service;

import br.com.riscos.domain.Ocorrencia;
import br.com.riscos.repository.OcorrenciaRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class OcorrenciaServiceTest {
  @Mock OcorrenciaRepository repository; @InjectMocks OcorrenciaService service;
  @Test void rejeitaOcorrenciaSemCliente(){Ocorrencia o=new Ocorrencia();o.setTipo(Ocorrencia.Tipo.KYC);o.setDescricao("x");assertThrows(Exception.class,()->service.criar(o));verifyNoInteractions(repository);}
  @Test void filtraPorTipo(){when(repository.findByTipo(Ocorrencia.Tipo.FRAUDE)).thenReturn(List.of());assertNotNull(service.listar(Ocorrencia.Tipo.FRAUDE,null));verify(repository).findByTipo(Ocorrencia.Tipo.FRAUDE);}
}
