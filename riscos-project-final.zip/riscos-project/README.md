# Sistema de Riscos — integração final

Base Spring Boot 3.2 para o sistema acadêmico de riscos, alinhada ao modelo Gold do diagrama: **CLIENTE**, **OCORRENCIA** e integração de leitura com Databricks SQL Statement Execution API. O ZIP original continha apenas quatro arquivos incompletos e não tinha frontend, autenticação, serviços ou testes; por isso a solução inclui uma base executável e um frontend mínimo.

## O que foi entregue

- API REST de ocorrências com filtros por `tipo` e `clienteId`.
- Regras de domínio para KYC, PLD, fraude e chargeback.
- RBAC via JWT/OIDC: escrita exige `risk:write` ou `ROLE_ADMIN`; leitura Databricks exige `risk:read` ou `ROLE_ADMIN`.
- Cliente Databricks server-side usando `POST /api/2.0/sql/statements`; token nunca é enviado ao frontend.
- Endpoint de saúde/capacidade: `GET /api/databricks/status` e `GET /api/auth/config`.
- Frontend em `frontend/index.html`, consumindo os endpoints reais.
- Testes automatizados de serviço e autorização MVC.

## Configuração

Execução local sem banco externo:

```bash
mvn spring-boot:run
# em outra janela
python3 -m http.server 5173 --directory frontend
```

Para produção, defina:

```bash
DATABASE_URL=jdbc:mysql://host:3306/sistema_riscos
DATABASE_USERNAME=...
DATABASE_PASSWORD=...
JPA_DDL_AUTO=validate
JWT_ISSUER_URI=https://seu-provedor-oidc.example.com
DATABRICKS_ENABLED=true
DATABRICKS_HOST=https://seu-workspace.cloud.databricks.com
DATABRICKS_TOKEN=              # secret manager; não commitar
DATABRICKS_WAREHOUSE_ID=...
DATABRICKS_CATALOG=main
DATABRICKS_SCHEMA=gold
FRONTEND_ORIGIN=https://seu-frontend.example.com
```

O conector Databricks fica desativado por padrão para permitir desenvolvimento/testes sem credencial. Com `JWT_ISSUER_URI` vazio, a aplicação fica aberta apenas para ambiente local; em produção essa variável é obrigatória e deve ser validada no deployment.

## API

- `GET /api/ocorrencias?tipo=PLD&clienteId=10`
- `POST /api/ocorrencias` com `{"clienteId":10,"tipo":"KYC","descricao":"..."}`
- `PUT /api/ocorrencias/{id}/status?status=RESOLVIDA`
- `POST /api/databricks/query` com `{"sql":"SELECT ..."}` — somente `SELECT`, protegido

## Validação

```bash
mvn test
mvn package -DskipTests
```

Os testes não inserem dados reais nem acessam Databricks. Para homologação, configure um warehouse de testes e adicione um teste de contrato com resposta mascarada da API Statement Execution.
