@RestController @RequestMapping("/api/ocorrencias")
public class OcorrenciaController {
 @Autowired OcorrenciaService service;

 @PostMapping
 public Ocorrencia criar(@RequestBody Ocorrencia o) { return service.salvar(o); }

 @GetMapping
 public List<Ocorrencia> listar() { return service.listarTodas(); }

 @GetMapping("/tipo/{tipo}")
 public List<Ocorrencia> porTipo(@PathVariable String tipo) { return service.porTipo(tipo); }

 @GetMapping("/cliente/{id}")
 public List<Ocorrencia> porCliente(@PathVariable Long id) { return service.porCliente(id); }

 @PutMapping("/{id}/status")
 public Ocorrencia atualizarStatus(@PathVariable Long id, @RequestParam String status) {
 return service.atualizarStatus(id, status);
 }
}
