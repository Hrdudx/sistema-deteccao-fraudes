@Entity
public class Cliente {
 @Id @GeneratedValue Long id_cliente;
 String tipo_pessoa; // PF ou PJ
 String nome_social;
 String cpf_cnpj;
 LocalDate data_cadastro;
 String origem_cadastro; // app/web
 String status_cliente;
 @OneToMany(mappedBy="cliente") List<Conta> contas;
}
